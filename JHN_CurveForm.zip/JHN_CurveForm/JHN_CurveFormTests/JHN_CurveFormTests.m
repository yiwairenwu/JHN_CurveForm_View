//
//  JHN_CurveFormTests.m
//  JHN_CurveFormTests
//
//  Created by cn.wz.jingzhi on 14-7-30.
//  Copyright (c) 2014年 cn.wenzhou. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface JHN_CurveFormTests : XCTestCase

@end

@implementation JHN_CurveFormTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
