//
//  JHNViewController.h
//  JHN_CurveForm
//
//  Created by cn.wz.jingzhi on 14-7-30.
//  Copyright (c) 2014年 cn.wenzhou. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JHN_CurveForm_View.h"
@interface JHNViewController : UIViewController<JHNCurveFormDelegate>

@end
